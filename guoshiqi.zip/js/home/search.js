define(['text!../../html/home/search.html', 'css!../../css/home/search'], function (html) {
	// 获取内容，将内容添加到container中
	// 将功能封装成函数
	$('.container').html(html);
});
